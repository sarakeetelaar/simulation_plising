You can install the development version from GitHub with:

install.packages('devtools')

devtools::install_github('sarakeetelaar/plising')
